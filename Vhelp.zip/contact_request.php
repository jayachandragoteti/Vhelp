<?PHP 
if (isset($_POST['name']) && isset($_POST['email']) && isset($_POST['contact'])  && isset($_POST['services'])  && isset($_POST['time'])  && isset($_POST['message'])) {
    if ($_POST['name'] != "" && $_POST['email'] !="" && $_POST['contact'] !="" && $_POST['services'] !="" && $_POST['time'] !="" && $_POST['message'] !="" ) {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $contact = $_POST['contact'];
        $services = $_POST['services'];
        $time = $_POST['time'];
        $message = $_POST['message'];
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            if (preg_match('/^[0-9]{3}[0-9]{3}[0-9]{4}$/', $contact)) {
                function password_generate($chars) 
                {
                    $data = 'QWERTYUIOPASDFGHJKLZXCVBNM12345678901234567890123456789QWERTYUIOPASDFGHJKLZXCVBNM';
                    return substr(str_shuffle($data), 0, $chars);
                }
                $request_id = "V-Help".date("Y").password_generate(6);
                /* ---------- Email Sending  ---------- */
                $subject = 'Service Request';
                $from = $email;
                // To send HTML mail, the Content-type header must be set
                $headers  = 'MIME-Version: 1.0' . "\r\n";
                $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
                // Create email headers
                $headers .= 'From: '.$from."\r\n".
                            'Reply-To: '.$from."\r\n" .
                            'X-Mailer: PHP/' . phpversion();
                // Compose a simple HTML email message
                $body =Service_Request_Mail($name,$email,$contact,$services,$time,$message,$request_id);
                if (mail('vhelp.2serveu@gmail.com',$subject,$body,$headers)) {
                    $subjec_2 = 'Request Confirmation';
                    $from_2 = 'vhelp.2serveu@gmail.com';
                    // To send HTML mail, the Content-type header must be set
                    $headers_2  = 'MIME-Version: 1.0' . "\r\n";
                    $headers_2 .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
                    // Create email headers
                    $headers_2 .= 'From: '.$from_2."\r\n".
                                'Reply-To: '.$from_2."\r\n" .
                                'X-Mailer: PHP/' . phpversion();
                    // Compose a simple HTML email message
                    $body_2 = Response_Mail($services,$request_id);
                    mail($email,$subject_2,$body_2,$headers_2);
                    echo "Thank you. We will contact soon,Check your email";
                }else {
                    echo "Failed try again!";
                }
                /* -------- End Email Sending  -------- */
            }else{
                echo 'Invalid Number!';
            }
        } else {
            echo $email." is not a valid email address";
        }
    } else {
        echo "* All fields must be filed!";
    }
}

function Service_Request_Mail($name,$email,$contact,$services,$time,$message,$request_id){ ob_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Skyline Ping Email</title>
    <style type="text/css">
        @import url(http://fonts.googleapis.com/css?family=Lato:400);

        /* Take care of image borders and formatting */

        img {
        max-width: 600px;
        outline: none;
        text-decoration: none;
        -ms-interpolation-mode: bicubic;
        }

        a {
        text-decoration: none;
        border: 0;
        outline: none;
        color: #21BEB4;
        }

        a img {
        border: none;
        }

        /* General styling */

        td, h1, h2, h3  {
        font-family: Helvetica, Arial, sans-serif;
        font-weight: 400;
        }

        body {
        -webkit-font-smoothing:antialiased;
        -webkit-text-size-adjust:none;
        width: 100%;
        height: 100%;
        color: #37302d;
        background: #ffffff;
        }

        table {
        background:
        }

        h1, h2, h3 {
        padding: 0;
        margin: 0;
        color: #ffffff;
        font-weight: 400;
        }

        h3 {
        color: #21c5ba;
        font-size: 24px;
        }
    </style>

    <style type="text/css" media="screen">
        @media screen {
        /* Thanks Outlook 2013! http://goo.gl/XLxpyl*/
        td, h1, h2, h3 {
            font-family: 'Lato', 'Helvetica Neue', 'Arial', 'sans-serif' !important;
        }
        }
    </style>

    <style type="text/css" media="only screen and (max-width: 480px)">
        /* Mobile styles */
        @media only screen and (max-width: 480px) {
        table[class="w320"] {
            width: 320px !important;
        }

        table[class="w300"] {
            width: 300px !important;
        }

        table[class="w290"] {
            width: 290px !important;
        }

        td[class="w320"] {
            width: 320px !important;
        }

        td[class="mobile-center"] {
            text-align: center !important;
        }

        td[class="mobile-padding"] {
            padding-left: 20px !important;
            padding-right: 20px !important;
            padding-bottom: 20px !important;
        }
        }
    </style>
    </head>
    <body class="body" style="padding:0; margin:0; display:block; background:#ffffff; -webkit-text-size-adjust:none" bgcolor="#ffffff">
    <table align="center" cellpadding="0" cellspacing="0" width="100%" height="100%" >
    <tr>
        <td align="center" valign="top" bgcolor="#ffffff"  width="100%">

        <table cellspacing="0" cellpadding="0" width="100%">
        <tr>
            <td style="border-bottom: 3px solid #3bcdc3;" width="100%">
            <center>
                <table cellspacing="0" cellpadding="0" width="500" class="w320">
                <tr>
                    <td valign="top" style="padding:10px 0; text-align:left;" class="mobile-center">
                    <img width="250" height="62" src="http://vhelp.girishfalcon.in/assets/img/Vhelp_logo.JPG">
                    </td>
                </tr>
                </table>
            </center>
            </td>
        </tr>
        <tr>
            <td valign="top">
            <center>
                <table cellspacing="0" cellpadding="0" width="500" class="w320">
                <tr>
                    <td>

                    <table cellspacing="0" cellpadding="0" width="100%">
                        <tr>
                        <td class="mobile-padding" style="text-align:left;">
                        <br>
                        <br>
                            Service Request for <b> <?PHP echo $services;?></b>
                            <br><br>
                            Service Request Id <b> <?PHP echo $request_id;?></b>
                            <br><br>
                                Customer Name :<?PHP echo $name;?>
                            <br>
                            <br>
                                Customer Email :<?PHP echo $email;?>
                            <br>
                            <br>
                                Customer Phone :<?PHP echo $contact;?>
                            <br>
                            <br>
                                Contact Timings :<?PHP echo $time;?>
                            <br>
                            <br>
                                Requirements :<?PHP echo $message;?>
                            <br>
                            <br>
                            </td>
                        </tr>
                    </table>
                    </td>
                </tr>
                <tr>
                    <td class="mobile-padding">
                    <br>
                    <br>
                    <br>
                    </td>
                </tr>
                </table>
            </center>
            </td>
        </tr>
        <tr>
            <td style="background-color:#c2c2c2;">
            <center>
                <table cellspacing="0" cellpadding="0" width="500" class="w320">
                <tr>
                    <td>
                    <table cellspacing="0" cellpadding="30" width="100%">
                        <tr>
                        <td style="text-align:center;">
                            
                            <a href="#">
                            
                            </a>
                        </td>
                        </tr>
                    </table>
                    </td>
                </tr>
                </table>
            </center>
            </td>
        </tr>
        </table>
        </td>
    </tr>
    </table>
    </body>
</html>
<?PHP return ob_get_clean(); }

function Response_Mail($services,$request_id){ ob_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Skyline Ping Email</title>
    <style type="text/css">
        @import url(http://fonts.googleapis.com/css?family=Lato:400);

        /* Take care of image borders and formatting */

        img {
        max-width: 600px;
        outline: none;
        text-decoration: none;
        -ms-interpolation-mode: bicubic;
        }

        a {
        text-decoration: none;
        border: 0;
        outline: none;
        color: #21BEB4;
        }

        a img {
        border: none;
        }

        /* General styling */

        td, h1, h2, h3  {
        font-family: Helvetica, Arial, sans-serif;
        font-weight: 400;
        }

        body {
        -webkit-font-smoothing:antialiased;
        -webkit-text-size-adjust:none;
        width: 100%;
        height: 100%;
        color: #37302d;
        background: #ffffff;
        }

        table {
        background:
        }

        h1, h2, h3 {
        padding: 0;
        margin: 0;
        color: #ffffff;
        font-weight: 400;
        }

        h3 {
        color: #21c5ba;
        font-size: 24px;
        }
    </style>

    <style type="text/css" media="screen">
        @media screen {
        /* Thanks Outlook 2013! http://goo.gl/XLxpyl*/
        td, h1, h2, h3 {
            font-family: 'Lato', 'Helvetica Neue', 'Arial', 'sans-serif' !important;
        }
        }
    </style>

    <style type="text/css" media="only screen and (max-width: 480px)">
        /* Mobile styles */
        @media only screen and (max-width: 480px) {
        table[class="w320"] {
            width: 320px !important;
        }

        table[class="w300"] {
            width: 300px !important;
        }

        table[class="w290"] {
            width: 290px !important;
        }

        td[class="w320"] {
            width: 320px !important;
        }

        td[class="mobile-center"] {
            text-align: center !important;
        }

        td[class="mobile-padding"] {
            padding-left: 20px !important;
            padding-right: 20px !important;
            padding-bottom: 20px !important;
        }
        }
    </style>
    </head>
    <body class="body" style="padding:0; margin:0; display:block; background:#ffffff; -webkit-text-size-adjust:none" bgcolor="#ffffff">
    <table align="center" cellpadding="0" cellspacing="0" width="100%" height="100%" >
    <tr>
        <td align="center" valign="top" bgcolor="#ffffff"  width="100%">

        <table cellspacing="0" cellpadding="0" width="100%">
        <tr>
            <td style="border-bottom: 3px solid #3bcdc3;" width="100%">
            <center>
                <table cellspacing="0" cellpadding="0" width="500" class="w320">
                <tr>
                    <td valign="top" style="padding:10px 0; text-align:left;" class="mobile-center">
                    <img width="250" height="62" src="http://vhelp.girishfalcon.in/assets/img/Vhelp_logo.JPG">
                    </td>
                </tr>
                </table>
            </center>
            </td>
        </tr>
        <tr>
            <td valign="top">
            <center>
                <table cellspacing="0" cellpadding="0" width="500" class="w320">
                <tr>
                    <td>

                    <table cellspacing="0" cellpadding="0" width="100%">
                        <tr>
                        <td class="mobile-padding" style="text-align:left;">
                        <br>
                        <br>
                            Dear Customer,<br><br>
                            Thank You for contacting VHelp. We're working on your request with service <?PHP echo $services;?>, We will get back to you within 8 business hours. (Monday to Saturday 9am to 6pm).
                            <br>
                            <br>
                            Request Id : <?PHP echo $request_id;?>
                            <br>
                            You can also contact us on below numbers during the business hours.<br>
                            <br>
                            Mobile No : 8790546457
                            <br>
                            Whatsapp  : 9110707105
                            <br><br>
                            Thank you so much.
                            <br>
                            <br>
                            Regards,
                            VHelp Team<br>
                            </td>
                        </tr>
                    </table>
                    </td>
                </tr>
                <tr>
                    <td class="mobile-padding">
                    <br>
                    <br>
                    <br>
                    </td>
                </tr>
                </table>
            </center>
            </td>
        </tr>
        <tr>
            <td style="background-color:#c2c2c2;">
            <center>
                <table cellspacing="0" cellpadding="0" width="500" class="w320">
                <tr>
                    <td>
                    <table cellspacing="0" cellpadding="30" width="100%">
                        <tr>
                        <td style="text-align:center;">
                            
                            <a href="#">
                            
                            </a>
                        </td>
                        </tr>
                    </table>
                    </td>
                </tr>
                </table>
            </center>
            </td>
        </tr>
        </table>
        </td>
    </tr>
    </table>
    </body>
</html>
<?PHP return ob_get_clean(); }